import Frame from "./structure/Frame"

function App() {

  return (
    <div className="">
      <Frame />
    </div>
  )
}

export default App
