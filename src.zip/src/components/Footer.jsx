import React from 'react'

export default function Footer() {
  return (
    <div cla>PrimotekNG @Copyright 2024 All Right Reserved</div>
  )
}
