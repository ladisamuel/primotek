import React from 'react'
import Header from '../components/Header'
import HomePage from '../pages/HomePage'
import Home from '../pages/Home2'

export default function Frame() {
  return (
    <div>
        {/* <Header />   */}
        <HomePage />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        {/* <Home /> */}
    </div>
  )
}
