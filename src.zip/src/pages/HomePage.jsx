import { React, useEffect, useState } from 'react';
import './HomePage.css'
import Home_header_hero from '../components/Home_header_hero';
import Separator from '../components/Separator';
import SolutionSection from '../componentscopy/SolutionSection';
import ImageSection from '../assets/backgrounds/home-8.jpg';
import Gradient_Btn from '../components/Gradient_Btn';
import numberImg from '../assets/icons/cctv.png';

function HomePage() {

    return (
        <div>
            <Home_header_hero />
            <Separator />
            <div className='lg:w-[40%] mx-auto text-center '>
                <h2 className='text-2xl mb-2 font-sans font-bold'>We Provide Best Engineering Solution To Client With Their Business Problem</h2>
                <p className='text-sm'>Including CCTV, access control, PBX, and home automation. Our article reveals the benefits of these cutting-edge technologies and how they can transform your property.</p>
            </div>
            <Separator />
            <div className="text-center">
                <Gradient_Btn bg="bg-white" />
            </div>
            <Separator />
            <div className='md:px-[50px] lg:px-[100px] pb-10 mb-10'>
                <SolutionSection />
            </div>
            <div className='slant_t_r relative h-[150px] z-0  lg:-mb-24 '>
                <div className="absolute bottom-0 z-50 left-1/2 -translate-x-1/2  ">
                    <Separator my='my-0'/>

                </div>
            </div>
            <div className="slant_b_r relative bg-[rgb(35,35,35)] pt-10">
                <div className="absolute top-0 z-50 left-1/2 -translate-x-1/2 p-2  ">
                    <Separator my='my-0' color='border-white' />
                </div>
                <div className={`my-20 md:px-[100px] lg:px-[20%] flex justify-center flex-wrap pt-20 h-[100px]`}>
                    <p className='services_list '><i className='pi pi-phone text-[white]'></i> Surveillance System</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> Access Control System</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> FM 200 Extinguishing</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> Fire Detection</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> Fire Hydrant</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> Building Management System</p>
                </div>
                
                <div className=" md:px-[50px] xs:px-5 pt-20 pb-10 lg:px-[100px] relative ">
                    <div className="md:flex items-center gap-20">
                        <div className="md:w-[50%] text-white flex flex-col gap-7 py-1 ">
                            
                            <p className='text-xs text-white'>WHO WE ARE</p>
                            <h1 className='text-3xl'>We run all kinds of software services that vow your success</h1>
                            <p className='text-white'>Accelerate innovation with world-class tech teams We’ll match you to an entire remote team of incredible freelance talent for all your software development needs.</p>
                            <div className="flex flex-start items-center gap-3 rounded-lg bg-[#4869e8] p-10">
                                <div className=" rounded-md w-fit"><i className="pi pi-bolt text-2xl"></i></div>
                                <p className='text-white'>Accelerate innovation with world-class tech teams We’ll match you to an entire remote.</p>
                            </div>
                            <div className="flex  items-center justify-center">
                                <div className="pr-3">
                                    <div className='mb-3'>
                                        <i className="pi pi-arrow-right text-xs text-[#4869e8] p-1 mr-2 rounded-full bg-white"></i>
                                        <span className='text-sm font-bold'> Expert Team</span>
                                    </div>
                                    <p className='text-white text-xs'>Accelerate innovation with world-class tech teams</p>
                                </div>
                                <div className="pr-3">
                                    <div className='mb-3'>
                                        <i className="pi pi-arrow-right text-xs text-[#4869e8] p-1 mr-2 rounded-full bg-white"></i>
                                        <span className='text-sm font-bold'> Expert Team</span>
                                    </div>
                                    <p className='text-white text-xs'>Accelerate innovation with world-class tech teams</p>
                                </div>
                            </div>
                        </div>
                        <div className="w-[50%]">
                            <div className='rounded-2xl overflow-hidden'>
                                <img src={ImageSection} alt="" />
                            </div>
                        </div>
                        
                    </div>
                </div>
                <Separator my='my-[0]' color='border-white'/>

                {/* <div className=''>
                    <Separator color='border-white absolute bottom-[20px] left-1/2  -translate-x-1/2' />
                </div> */}
                {/*  absolute top-full left-1/2 -translate-x-1/2 -translate-y-1/2  */}
                {/*   rounded-5 w-fit my-2 border_gradient */}
                {/* <div className='border border-red-400 z-[50] '>
                    <Separator color='border-white'/>
                    <div className='text-center '>
                        <Gradient_Btn/>
                    </div>
                    <Separator />
                </div> */}
                {/* <div className='pt-1 bg-[white]  '>
                    <Separator />

                </div> */}

            </div>
            <Separator my='my-[0]' />
            <div>
                <div className='md:px-[50px] xs:px-5 lg:px-[100px] pt-20 bg[red] m-auto'>
                    <div className='grid  grid-cols-1 lg:grid-cols-3 items-center '>
                        <div className='flex items-center justify-start '>
                            <h4 className=' text-[10rem] text-slate-800 font-bold'>01</h4>
                            <p className='text-4xl -ml-5 text-[blue]'>Mechanical Fire Fighting</p>
                        </div>
                        <div className='w-[250px] h-[250px] m-auto border-4 border-[grey] flex items-center justify-center rounded-full overflow-hidden'>
                            <img src={numberImg} className=' w-[95%] bg-white h-[85%] m-auto rounded-ful' alt="" />
                        </div>
                        <p className='float-end '>We define your competition and target audience. Discover what is working in your online industry, then design your website accordingly.</p>
                    </div>
                </div>
                <div className='md:px-[50px] xs:px-5 lg:px-[100px] pt-20 bg[red] m-auto'>
                    <div className='grid  grid-cols-1 lg:grid-cols-3 items-center   '>
                        <p className='float-end text-danger-500'>We define your competition and target audience. Discover what is working in your online industry, then design your website accordingly.</p>
                        <div className='w-[250px] h-[250px] m-auto border-4 border-[grey] flex items-center justify-center rounded-full overflow-hidden'>
                            <img src={numberImg} className=' w-[95%] bg-white h-[85%] m-auto rounded-ful' alt="" />
                        </div>
                        <div className='flex items-center justify-start '>
                            <h4 className=' text-[10rem] text-danger-500 font-bold'>02</h4>
                            <p className='text-4xl -ml-5 text-[blue]'>Extra Low Voltage</p>
                        </div>
                        
                    </div>
                </div>
                <div className='md:px-[50px] xs:px-5 lg:px-[100px] pt-20 bg[red] m-auto'>
                    <div className='grid grid-cols-1 lg:grid-cols-3 items-center '>
                        <div className='flex items-center justify-start '>
                            <h4 className=' text-[10rem] text-lime-500 font-bold'>03</h4>
                            <p className='text-4xl -ml-5 text-[blue]'>Extra Low Voltage</p>
                        </div>
                        <div className='w-[250px] h-[250px] m-auto border-4 border-[grey] flex items-center justify-center rounded-full overflow-hidden'>
                            <img src={numberImg} className=' w-[95%] bg-white h-[85%] m-auto rounded-ful' alt="" />
                        </div>
                        <p className='float-end text-lime-500'>We define your competition and target audience. Discover what is working in your online industry, then design your website accordingly.</p>
                    </div>
                </div>

                <Separator />
                <div className="text-center">
                    <Gradient_Btn bg="bg-white" />
                </div>
                <Separator />
                
                <div className=" my-5 md:px-[100px] lg:px-[20%] flex justify-center flex-wrap">
                    <p className='services_list '><i className='pi pi-phone text-[white]'></i> Surveillance System</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> Access Control System</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> FM 200 Extinguishing</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> Fire Detection</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> Fire Hydrant</p>
                    <p className='services_list'><i className='pi pi-phone text-[white]'></i> Building Management System</p>
                </div>
                
                <Separator />
                    
                <div className='lg:w-[40%] mx-auto text-center '>
                    <h2 className='text-2xl mb-2 font-sans font-bold'>Amazing Team</h2>
                    <p className='text-sm'>Meet our exceptional team of passionate engineers committed to delivering high-quality solutions for you.</p>
                </div>
                <Separator />
                
            </div>


        </div>

    )
  }
  
export default HomePage